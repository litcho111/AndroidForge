# Lernux — native Android learning app (starter v0.1.0)

Lernux is a native Android app built with Kotlin and Jetpack Compose — not a web app or HTML wrapper.

## Included in this starter
- Native Compose UI with bottom navigation
- Selectable school subjects
- Adaptive-learning entry flow with an honesty prompt
- Example history diagnostic quiz with “Weiß ich nicht” and feedback
- Vocabulary cards, batch size selection, reveal/next navigation, and add-your-own vocabulary during the current session
- XP, level progress, achievement milestones
- Theme accent choices (red, blue, violet, green, amber)
- Persistent preferences for XP, completed activities, subject, theme and effects
- Motion via Compose animated screen entry and progress UI

## Important prototype notes
- This is a first working foundation, not a finished production release.
- The sample history quiz is demo content. Other subjects currently reuse the sample question set and need their own content packs.
- Vocabulary cards currently live in memory during the session; durable vocabulary storage, a full spaced-repetition engine, editable custom lessons, timed exam configuration, real lightning/particle rendering, backup/sync, and AI integration are planned next steps.
- The lightning switch currently enables the effect state and unlock tracking; a full animated lightning renderer has not been implemented yet.
- XP is awarded by completing quiz questions and vocabulary rounds; this starter uses a simple score model rather than a validated grading system.

## Build an APK in Android Studio
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (JDK 17 or 21).
2. Open this `lernux` folder as a project.
3. Let Gradle sync and download the Android/Compose dependencies.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

Application ID: `de.lernux.app`
Minimum Android version: Android 8.0 (API 26)
