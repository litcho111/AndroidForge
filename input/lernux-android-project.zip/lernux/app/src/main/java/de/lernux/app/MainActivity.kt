package de.lernux.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0B0D10)
private val Panel = Color(0xFF171A20)
private val Muted = Color(0xFF9AA3B2)
private val AccentRed = Color(0xFFFF4D5A)
private val AccentBlue = Color(0xFF58C8FF)
private val AccentPurple = Color(0xFFB69CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LernuxApp(this) }
    }
}

private enum class Page(val label: String) { Home("Start"), Learn("Lernen"), Vocab("Vokabeln"), Exam("Prüfung"), Rewards("Erfolge"), Design("Design") }
private data class Flashcard(val front: String, val back: String)

@Composable
private fun LernuxApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("lernux", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf(Page.Home) }
    var subject by remember { mutableStateOf(prefs.getString("subject", "Geschichte") ?: "Geschichte") }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 1)) }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "Rot") ?: "Rot") }
    var effects by remember { mutableStateOf(prefs.getBoolean("effects", false)) }
    var honest by remember { mutableStateOf(false) }
    var questionIndex by remember { mutableIntStateOf(0) }
    var showAnswer by remember { mutableStateOf(false) }
    var selectedAnswer by remember { mutableStateOf(-1) }
    var newFront by remember { mutableStateOf("") }
    var newBack by remember { mutableStateOf("") }
    var vocabBatch by remember { mutableIntStateOf(5) }
    var vocabBatchText by remember { mutableStateOf("5") }
    val accent = when (theme) { "Blau" -> AccentBlue; "Violett" -> AccentPurple; "Grün" -> Color(0xFF6BE3A1); "Amber" -> Color(0xFFFFC56D); else -> AccentRed }
    val cards = remember { mutableStateListOf(Flashcard("bonjour", "Hallo"), Flashcard("merci", "Danke"), Flashcard("la maison", "das Haus"), Flashcard("le livre", "das Buch"), Flashcard("l'école", "die Schule"), Flashcard("apprendre", "lernen"), Flashcard("aujourd'hui", "heute"), Flashcard("toujours", "immer")) }
    val historyQuestions = listOf(
        Triple("Wann begann die Französische Revolution?", listOf("1789", "1815", "1848"), 0),
        Triple("Was war der Dritte Stand?", listOf("Adel", "Die große Mehrheit der Bevölkerung", "Klerus"), 1),
        Triple("Was bedeutete die Erklärung der Menschen- und Bürgerrechte?", listOf("Gleiche Rechte als Leitidee", "Rückkehr zum Feudalismus", "Abschaffung aller Gesetze"), 0),
        Triple("Wann wurde Napoleon Kaiser?", listOf("1792", "1804", "1812"), 1)
    )
    fun award(points: Int) {
        xp += points; completed += 1
        prefs.edit().putInt("xp", xp).putInt("completed", completed).putInt("streak", streak).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, secondary = AccentBlue, background = Ink, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                listOf(Page.Home, Page.Learn, Page.Vocab, Page.Rewards, Page.Design).forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item }, icon = {
                        Icon(when(item) { Page.Home -> Icons.Default.Home; Page.Learn -> Icons.Default.MenuBook; Page.Vocab -> Icons.Default.Style; Page.Rewards -> Icons.Default.EmojiEvents; else -> Icons.Default.Palette }, null)
                    }, label = { Text(item.label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accent, indicatorColor = accent.copy(alpha = .16f), selectedTextColor = accent, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            AnimatedVisibility(true, enter = fadeIn() + slideInVertically(initialOffsetY = { it / 18 })) {
                LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item { Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) { Text("L E R N U X", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp); Text(when(page) { Page.Home -> "Dein Lernzentrum"; Page.Learn -> "Themen lernen"; Page.Vocab -> "Vokabeltraining"; Page.Exam -> "Prüfungsmodus"; Page.Rewards -> "Deine Erfolge"; Page.Design -> "Designstudio" }, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
                        Box(Modifier.size(46.dp).clip(CircleShape).background(accent.copy(alpha = .16f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = accent, modifier = Modifier.size(26.dp)) }
                    } }
                    when(page) {
                        Page.Home -> {
                            item { CardPanel(accent) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text("Level ${xp / 100 + 1}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Noch ${100 - xp % 100} XP bis zum nächsten Level", color = Muted, fontSize = 12.sp) }
                                    Text("${xp} XP", color = accent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                }
                                Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { (xp % 100) / 100f }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = accent, trackColor = Color(0xFF30343D))
                            } }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("Heute gelernt", "$completed", Icons.Default.CheckCircle, Modifier.weight(1f), accent); StatCard("Lernserie", "$streak Tage", Icons.Default.LocalFireDepartment, Modifier.weight(1f), accent) } }
                            item { SectionTitle("Weitermachen", "Dein nächster Schritt") }
                            item { ActionCard("Adaptives Lernen", "Teste dein Wissen und lerne gezielt Lücken", Icons.Default.Psychology, accent) { page = Page.Learn } }
                            item { ActionCard("Vokabeln üben", "Neue Wörter in kleinen Gruppen lernen", Icons.Default.Style, accent) { page = Page.Vocab } }
                            item { ActionCard("Prüfung simulieren", "Teste dich ohne Lernhilfen", Icons.Default.Timer, accent) { page = Page.Exam; questionIndex = 0; selectedAnswer = -1; honest = false } }
                            item { SectionTitle("Dein Fach", "Wähle, woran du arbeitest") }
                            item { SubjectPicker(subject, accent) { subject = it; prefs.edit().putString("subject", it).apply() } }
                        }
                        Page.Learn -> {
                            item { Text("Fach auswählen", color = Muted) }
                            item { SubjectPicker(subject, accent) { subject = it; prefs.edit().putString("subject", it).apply() } }
                            item { CardPanel(accent) {
                                Text("Erst wissen, dann gezielt lernen", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("Beantworte die Einstiegsfragen ehrlich. So kann Lernux unterscheiden, was du schon kannst und was du noch üben solltest.", color = Muted)
                                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = honest, onCheckedChange = { honest = it }, colors = CheckboxDefaults.colors(checkedColor = accent)); Text("Ich antworte ehrlich – auch mit ‚Weiß ich nicht‘", fontSize = 12.sp) }
                                Button(onClick = { questionIndex = 0; selectedAnswer = -1; page = Page.Exam }, enabled = honest, colors = ButtonDefaults.buttonColors(containerColor = accent), modifier = Modifier.fillMaxWidth()) { Text("Wissenstest starten") }
                            } }
                            item { SectionTitle("Lernablauf", "In kleinen Schritten") }
                            item { ActionCard("1 · Verstehen", "Eine klare Erklärung mit Beispielen", Icons.Default.Lightbulb, accent) {} }
                            item { ActionCard("2 · Gemeinsam üben", "Kurze Aufgaben mit direktem Feedback", Icons.Default.EditNote, accent) {} }
                            item { ActionCard("3 · Selbst anwenden", "Eigene Lösung oder Rechenweg formulieren", Icons.Default.TaskAlt, accent) {} }
                            item { ActionCard("4 · Wissenslücken wiederholen", "Schwierige Fragen kommen öfter zurück", Icons.Default.Replay, accent) {} }
                        }
                        Page.Vocab -> {
                            item { Text("Eigene Vokabeln hinzufügen", color = Muted) }
                            item { CardPanel(accent) {
                                OutlinedTextField(value = newFront, onValueChange = { newFront = it }, label = { Text("Vorderseite / Fremdwort") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedTextField(value = newBack, onValueChange = { newBack = it }, label = { Text("Rückseite / Übersetzung") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                Button(onClick = { if (newFront.isNotBlank() && newBack.isNotBlank()) { cards.add(Flashcard(newFront.trim(), newBack.trim())); newFront = ""; newBack = "" } }, colors = ButtonDefaults.buttonColors(containerColor = accent), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Vokabel hinzufügen") }
                            } }
                            item { CardPanel(accent) {
                                Text("Lernportion", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("Wie viele neue Wörter sollen zuerst drankommen?", color = Muted, fontSize = 13.sp)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    listOf(3,5,8,10).forEach { n -> FilterChip(selected = vocabBatch == n, onClick = { vocabBatch = n; vocabBatchText = "$n" }, label = { Text("$n") }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accent.copy(alpha=.22f))) }
                                }
                                Text("${cards.size} Vokabeln in deiner Liste", color = Muted, fontSize = 12.sp)
                            } }
                            item { SectionTitle("Lernrunde", "Karte ${questionIndex + 1} von ${minOf(vocabBatch, cards.size)}") }
                            item { CardPanel(accent) {
                                val count = minOf(vocabBatch, cards.size).coerceAtLeast(1)
                                val current = cards[questionIndex.coerceIn(0, count - 1)]
                                Text(if (showAnswer) current.back else current.front, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                Text(if (showAnswer) "Übersetzung" else "Versuche die Antwort zu erinnern", color = Muted)
                                Button(onClick = { showAnswer = !showAnswer }, colors = ButtonDefaults.buttonColors(containerColor = accent), modifier = Modifier.fillMaxWidth()) { Text(if (showAnswer) "Wort ansehen" else "Antwort zeigen") }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { questionIndex = if (questionIndex <= 0) count - 1 else questionIndex - 1; showAnswer = false }, modifier = Modifier.weight(1f)) { Text("Zurück") }
                                    Button(onClick = { if (questionIndex + 1 >= count) { award(10); questionIndex = 0 } else questionIndex++; showAnswer = false }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text(if (questionIndex + 1 >= count) "Runde beenden" else "Weiter") }
                                }
                            } }
                            item { Text("Hinweis: Die Vokabelliste wird in dieser ersten Version noch während der App-Sitzung gehalten. Dauerhafte Speicherung der Inhalte ist als nächster Ausbaupunkt vorgesehen.", color = Muted, fontSize = 11.sp) }
                        }
                        Page.Exam -> {
                            item { CardPanel(accent) {
                                Text("Ehrlich lernen funktioniert besser", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("Wähle die Antwort, die du wirklich weißt. ‚Weiß ich nicht‘ ist besser als Raten, wenn du unsicher bist.", color = Muted, fontSize = 13.sp)
                            } }
                            item { SectionTitle("${subject} · Wissenstest", "Frage ${questionIndex + 1} von ${historyQuestions.size}") }
                            item { CardPanel(accent) {
                                val q = historyQuestions[questionIndex.coerceIn(0, historyQuestions.lastIndex)]
                                Text(q.first, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                q.second.forEachIndexed { index, answer ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(if (selectedAnswer == index) accent.copy(alpha = .18f) else Color(0xFF22262E)).clickable { selectedAnswer = index }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = selectedAnswer == index, onClick = { selectedAnswer = index }, colors = RadioButtonDefaults.colors(selectedColor = accent))
                                        Text(answer, modifier = Modifier.padding(start = 5.dp), fontSize = 14.sp)
                                    }
                                }
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(if (selectedAnswer == 3) accent.copy(alpha=.18f) else Color(0xFF22262E)).clickable { selectedAnswer = 3 }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = selectedAnswer == 3, onClick = { selectedAnswer = 3 }, colors = RadioButtonDefaults.colors(selectedColor = accent)); Text("Weiß ich nicht", modifier = Modifier.padding(start = 5.dp))
                                }
                                if (selectedAnswer >= 0) {
                                    val correct = selectedAnswer == q.third
                                    Text(if (correct) "Richtig! Gut gewusst." else if (selectedAnswer == 3) "Alles gut – das üben wir noch." else "Noch nicht ganz. Die richtige Antwort ist: ${q.second[q.third]}.", color = if (correct) Color(0xFF6BE3A1) else accent, fontWeight = FontWeight.SemiBold)
                                }
                                Button(onClick = {
                                    if (selectedAnswer >= 0) {
                                        if (selectedAnswer == q.third) award(10) else award(2)
                                        if (questionIndex < historyQuestions.lastIndex) questionIndex++ else { questionIndex = 0; page = Page.Rewards }
                                        selectedAnswer = -1
                                    }
                                }, enabled = selectedAnswer >= 0, colors = ButtonDefaults.buttonColors(containerColor = accent), modifier = Modifier.fillMaxWidth()) { Text(if (questionIndex == historyQuestions.lastIndex) "Test abschließen" else "Antwort prüfen & weiter") }
                            } }
                        }
                        Page.Rewards -> {
                            item { CardPanel(accent) { Text("Dein Lernfortschritt", fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("$xp XP gesammelt", color = accent, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Du machst Fortschritt, wenn du übst – nicht nur, wenn alles sofort richtig ist.", color = Muted) } }
                            item { SectionTitle("Erfolge", "Deine Meilensteine") }
                            item { Achievement("Erster Schritt", "Beantworte deine erste Lernfrage", completed >= 1, Icons.Default.Flag, accent) }
                            item { Achievement("Wissenssammler", "Sammle 100 XP", xp >= 100, Icons.Default.AutoAwesome, accent) }
                            item { Achievement("Dranbleiber", "Schließe 10 Lernaktivitäten ab", completed >= 10, Icons.Default.LocalFireDepartment, accent) }
                            item { Achievement("Design-Entdecker", "Probiere einen Effekt aus", effects, Icons.Default.Bolt, accent) }
                            item { Text("Freischaltbare Designs", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { ThemeReward("Blitz", "${if (xp >= 50) "Freigeschaltet" else "50 XP nötig"}", xp >= 50, accent); ThemeReward("Partikel", "${if (xp >= 100) "Freigeschaltet" else "100 XP nötig"}", xp >= 100, accent) } }
                        }
                        Page.Design -> {
                            item { Text("Passe Lernux an deinen Geschmack an.", color = Muted) }
                            item { CardPanel(accent) {
                                Text("Akzentfarbe", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                listOf("Rot", "Blau", "Violett", "Grün", "Amber").forEach { c ->
                                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { theme = c; prefs.edit().putString("theme", c).apply() }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(24.dp).clip(CircleShape).background(when(c) { "Blau" -> AccentBlue; "Violett" -> AccentPurple; "Grün" -> Color(0xFF6BE3A1); "Amber" -> Color(0xFFFFC56D); else -> AccentRed }))
                                        Text(c, modifier = Modifier.weight(1f).padding(start = 12.dp)); if (theme == c) Icon(Icons.Default.CheckCircle, null, tint = accent)
                                    }
                                }
                            } }
                            item { CardPanel(accent) {
                                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Blitz-Hintergrund", fontWeight = FontWeight.Bold); Text("Dezente Lichtimpulse hinter der Oberfläche", color = Muted, fontSize = 12.sp) }; Switch(checked = effects, onCheckedChange = { effects = it; prefs.edit().putBoolean("effects", it).apply(); if (it) award(0) }, colors = SwitchDefaults.colors(checkedThumbColor = accent)) }
                                if (effects) { Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Bolt, null, tint = accent, modifier = Modifier.size(32.dp)); Text("Effekt aktiviert", color = accent, fontWeight = FontWeight.Bold) } }
                            } }
                            item { CardPanel(accent) { Text("Animationen", fontWeight = FontWeight.Bold); Text("Lernux nutzt sanfte Einblendungen und animierte Fortschrittsbalken. Mehr Effektarten und Intensitätsregler können in weiteren Versionen ergänzt werden.", color = Muted, fontSize = 13.sp) } }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun CardPanel(accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}
@Composable private fun SectionTitle(title: String, subtitle: String) { Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp) } }
@Composable private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, accent: Color) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Icon(icon, null, tint = accent); Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(title, color = Muted, fontSize = 11.sp) }
}
@Composable private fun ActionCard(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable { onClick() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, color = Muted, fontSize = 12.sp) }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}
@Composable private fun SubjectPicker(selected: String, accent: Color, onSelected: (String) -> Unit) {
    val subjects = listOf("Geschichte", "Mathe", "Französisch", "Englisch", "Biologie", "Deutsch")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { subjects.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { subject -> FilterChip(selected = selected == subject, onClick = { onSelected(subject) }, label = { Text(subject) }, leadingIcon = if (selected == subject) ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }) else null, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accent.copy(alpha = .2f), selectedLabelColor = Color.White), modifier = Modifier.weight(1f)) } } } }
}
@Composable private fun Achievement(title: String, desc: String, unlocked: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(if (unlocked) accent.copy(alpha=.18f) else Color(0xFF292D35)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = if (unlocked) accent else Muted) }
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 12.sp) }
        Icon(if (unlocked) Icons.Default.CheckCircle else Icons.Default.Lock, null, tint = if (unlocked) accent else Muted)
    }
}
@Composable private fun ThemeReward(title: String, desc: String, unlocked: Boolean, accent: Color) {
    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Panel).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Icon(if (unlocked) Icons.Default.Bolt else Icons.Default.Lock, null, tint = if (unlocked) accent else Muted); Text(title, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 11.sp) }
}
